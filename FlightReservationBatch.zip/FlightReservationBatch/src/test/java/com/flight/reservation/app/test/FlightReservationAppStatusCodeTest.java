package com.flight.reservation.app.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.flight.reservation.app.model.ResponseDTO;
import com.flight.reservation.app.services.DataValidationService;

public class FlightReservationAppStatusCodeTest {

	@Test
	public void testStatusCode() {
		// Assume you have a method that returns a ResponseEntity with a status code
		// This is just an example, replace it with your actual method or code
//		Map<String,String> queryMap = new HashMap<String,String>();
//		queryMap.put("type","user");
//		DataValidationService dataValidationService = new DataValidationService();
//        ResponseDTO response = dataValidationService.validateQueryParams(queryMap);

		// Verify that the status code is 200
//        assertEquals(200, response.getCode());
	}

}
