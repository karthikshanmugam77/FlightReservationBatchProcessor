package com.flight.reservation.app.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightReservationBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
