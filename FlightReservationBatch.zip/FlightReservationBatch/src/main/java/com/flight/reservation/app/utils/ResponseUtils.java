package com.flight.reservation.app.utils;

public class ResponseUtils {
	
	public static final String RESPONSE_CODE_200 = "200";
	public static final String RESPONSE_CODE_400 = "400";
	public static final String RESPONSE_CODE_404 = "404";

	public static final String RESPONSE_STATUS_200 = "success";
	public static final String RESPONSE_STATUS_400 = "Bad Request";
	public static final String RESPONSE_STATUS_404 = "Data Not Found";

	public static final String RESPONSE_MSG_200 = "success";
	public static final String RESPONSE_MSG_400 = "Bad Request";

}
