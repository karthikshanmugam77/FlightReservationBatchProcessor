package com.flight.reservation.app.services;

import org.springframework.stereotype.Service;

import com.flight.reservation.app.entities.User;
import com.flight.reservation.app.helper.RetrieveUsersHelper;
import com.flight.reservation.app.model.ResponseDTO;

@Service
public class RetrieveUsersService extends RetrieveUsersHelper{

	public long retrieveDataCount(String type) {
		if (type.equalsIgnoreCase("user")) {
			return retrieveUserCount();
		}
		if(type.equalsIgnoreCase("role")){
			return retrieveUserRolesCount();
		}
		return 0;
	}
	
	private long retrieveUserCount() {
		return getAllUserCount();
	}

	private long retrieveUserRolesCount() {
		return getAllRolesCount();
	}

	public ResponseDTO retrieveRecordByEmail(String email) {
		 User recordByEmail = getRecordByEmail(email);
		 return new ResponseDTO(recordByEmail);
	}

	public ResponseDTO retrieveRecordByFirstName(String firstName) {
		 User recordByFirstName = getRecordByFirstName(firstName);
		return new ResponseDTO(recordByFirstName);
	}

}
