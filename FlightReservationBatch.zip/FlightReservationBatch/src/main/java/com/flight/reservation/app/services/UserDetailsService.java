package com.flight.reservation.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.reservation.app.entities.User;
import com.flight.reservation.app.model.ResponseDTO;
import com.flight.reservation.app.repository.UserRepository;

@Service
public class UserDetailsService {
	
	@Autowired
	UserRepository userRepository;

//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		User user = userRepository.findByEmail(username);
//		if(user==null) {
//			throw new UsernameNotFoundException("User not found for Mail: " + username);
//		}
//		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), user.getRoles());
//	}
	
	public ResponseDTO saveRec (User user) {
		userRepository.save(user);
		return new ResponseDTO("200","Success","persisted successfully");
	}		
}
