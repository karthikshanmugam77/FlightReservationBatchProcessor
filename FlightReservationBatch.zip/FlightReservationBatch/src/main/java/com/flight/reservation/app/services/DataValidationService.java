package com.flight.reservation.app.services;

import java.util.Arrays;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.flight.reservation.app.model.ResponseDTO;
import com.flight.reservation.app.utils.ValidationUtils;

@Service
public class DataValidationService {

	public ResponseDTO validateQueryParams(Map<String, String> queryParams) {
		if(queryParams.get("type")!=null) {
			if (Arrays.asList(ValidationUtils.allowedTypes).contains(queryParams.get("type").toLowerCase())) {
			return new ResponseDTO("200");
			}
		}
		return new ResponseDTO("400");
	}
}