package com.flight.reservation.app.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.flight.reservation.app.model.DbRequestDTO;
import com.flight.reservation.app.model.ResponseDTO;
import com.flight.reservation.app.repository.RoleRepository;
import com.flight.reservation.app.repository.UserRepository;

@Component
public class BatchProcessHelper {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	RoleRepository roleRepository;
	
	 public static String TYPE = "text/csv";
	  static String[] HEADERs = { "id","firstName", "lastName", "email", "password","name"};

	  public static boolean validateCSVFormat(MultipartFile file) { //validation method to CSV

	    if (!TYPE.equals(file.getContentType())) {
	      return false;
	    }

	    return true;
	  }
	  
	  public static Iterable<CSVRecord> csvToRecordParser(InputStream is) { //CSV parser method 
		    try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
		        CSVParser csvParser = new CSVParser(fileReader,
		            CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {
		      return csvParser.getRecords();
		    } catch (IOException e) {
		    	System.out.println(" fail to parse CSV file: ");
		      throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
		    }
		  }

	public ResponseDTO persistToDb(DbRequestDTO dbRequest) { // helper method to persist data to DB
		try {
			userRepository.saveAll(dbRequest.getUserRec());
			roleRepository.saveAll(dbRequest.getRoleRec());
//		userList.stream().forEach(userItem -> {
//			userRepository.save(userItem);
//		});
		return new ResponseDTO("200","success", dbRequest.getUserRec().size() + " records processed succesfully");}
		catch(Exception e) {
			System.out.println(" Exception while processing !" + e.getLocalizedMessage());
			return new ResponseDTO("400","Bad Request","Processing failed");
		}
		
	}

}
