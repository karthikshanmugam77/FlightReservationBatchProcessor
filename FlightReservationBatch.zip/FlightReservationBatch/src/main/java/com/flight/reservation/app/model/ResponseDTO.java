package com.flight.reservation.app.model;

import com.flight.reservation.app.entities.User;

public class ResponseDTO {

	private String code;
	private String status;
	private String message;
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ResponseDTO(String code, String status, String message) {
		super();
		this.code = code;
		this.status = status;
		this.message = message;
	}

	public ResponseDTO(String code) {
		super();
		this.code = code;
	}

	public ResponseDTO(User user) {
		super();
		// TODO Auto-generated constructor stub
	}

}
