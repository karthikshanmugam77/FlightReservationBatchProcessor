package com.flight.reservation.app.services;

import java.io.IOException;
import java.util.List;

import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.flight.reservation.app.entities.User;
import com.flight.reservation.app.helper.BatchProcessHelper;
import com.flight.reservation.app.mapper.RequestMapper;
import com.flight.reservation.app.model.DbRequestDTO;
import com.flight.reservation.app.model.ResponseDTO;

@Service
public class BatchProcessorService {
	
	@Autowired
	BatchProcessHelper csvHelper;
	
	@Autowired
	RequestMapper requestMapper;

	public ResponseDTO csvToListProcessor(MultipartFile file) throws IOException {
		
		Iterable<CSVRecord> csvAsRecords = BatchProcessHelper.csvToRecordParser(file.getInputStream()); // parsing CSV to CSVRecords format
		 DbRequestDTO dbRequest = requestMapper.SqlRequestMapper(csvAsRecords); // processing CSVRecords to POJO
		return csvHelper.persistToDb(dbRequest); // finally persisting to DB
	}
	
	

}
