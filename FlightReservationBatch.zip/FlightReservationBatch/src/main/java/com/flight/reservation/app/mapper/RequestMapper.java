package com.flight.reservation.app.mapper;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;

import com.flight.reservation.app.entities.Role;
import com.flight.reservation.app.entities.User;
import com.flight.reservation.app.model.DbRequestDTO;

@Service
public class RequestMapper {
	
	public DbRequestDTO SqlRequestMapper(Iterable<CSVRecord> csvRecords){
		
		List <User> userRec = new ArrayList<>();
		List <Role> roleRec = new ArrayList<>();
		
		  for (CSVRecord csvRecord : csvRecords) { // parsing the CSVrecords to user POJO
			  User user = new User();
			  Role role= new Role();
			  role.setUserRole(csvRecord.get("role"));
			  user.setRoles(role);
			  user.setFirstName(csvRecord.get("firstName"));
			  user.setLastName(csvRecord.get("lastName"));
			  user.setEmail(csvRecord.get("email"));
			  user.setPassword(csvRecord.get("password"));
			  user.setId(csvRecord.get("id"));
			  userRec.add(user); // adding object to arrayList
			  roleRec.add(role);
		  }
		  DbRequestDTO dbRequestDTO = new DbRequestDTO();
		  dbRequestDTO.setRoleRec(roleRec);
		  dbRequestDTO.setUserRec(userRec);
		  return dbRequestDTO; // returning total parsed records as list
	}

}
