package com.flight.reservation.app.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.flight.reservation.app.entities.User;
import com.flight.reservation.app.helper.BatchProcessHelper;
import com.flight.reservation.app.model.ResponseDTO;
import com.flight.reservation.app.services.BatchProcessorService;
import com.flight.reservation.app.services.DataValidationService;
import com.flight.reservation.app.services.RetrieveUsersService;
import com.flight.reservation.app.utils.ResponseUtils;

@RestController
public class FlightReservationController {
	/*
	 * 
	 * @version 1.0
	 * 
	 * @since 2024-01-16
	 * 
	 * @author Karthikeyan Balashanmugam
	 * 
	 */

	@Autowired
	BatchProcessorService batchService;
	
	@Autowired
	DataValidationService dataValidationService;

	@Autowired
	RetrieveUsersService retrieveService;

	private static final Logger LOGGER = LoggerFactory.getLogger(FlightReservationController.class);

	@RequestMapping(value = "/uploadCSV", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<ResponseDTO> uploadFile(@RequestParam("file") MultipartFile file) { // This method takes a file as input
		if (BatchProcessHelper.validateCSVFormat(file)) { // validating the CSV format
			String message = "";
			try {
				ResponseDTO processResponse = batchService.csvToListProcessor(file); // calling a processor function in autowired class
				if (processResponse.getCode().equalsIgnoreCase("200")) {
					message = "Uploaded the file successfully: " + file.getOriginalFilename() + "\n"; // appending proper error msgs
					processResponse.setMessage(processResponse.getMessage().concat(message));
					LOGGER.info("processed sucessfully");
					return ResponseEntity.status(HttpStatus.OK).body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_200, ResponseUtils.RESPONSE_STATUS_200, message)); // response entity and body using constructor
				}
			} catch (Exception e) {
				LOGGER.error("Exception failed" + e.getLocalizedMessage());
				message = "Could not upload the file: " + file.getOriginalFilename() + "!";// building custom exception msg
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
						.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_400, ResponseUtils.RESPONSE_STATUS_400, message));// response entity and body using constructor
			}
		}
		LOGGER.error("validation failed");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_400, ResponseUtils.RESPONSE_STATUS_400, "Please upload a csv file!"));// response entity and body using constructor
	}

	@RequestMapping(value = "/showCountDetails", method = RequestMethod.GET)
	public ResponseEntity<ResponseDTO> retrieveAllusers(
			@RequestParam(required = false) Map<String, String> queryParams) {

		try {
			ResponseDTO validationResponse = dataValidationService.validateQueryParams(queryParams);
			if(validationResponse.getCode().equalsIgnoreCase("200")) {
			long usersCount = retrieveService.retrieveDataCount(queryParams.get("type"));
			String message = "Total user present : " + usersCount;
			if (usersCount != 0) {
				LOGGER.info("Transaction success");
				return ResponseEntity.status(HttpStatus.OK).body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_200, ResponseUtils.RESPONSE_STATUS_200, message));
			} else {
				LOGGER.info("Data not found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND)
						.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_404, ResponseUtils.RESPONSE_STATUS_404, message));
			}}
			LOGGER.info("validation failed");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_400, ResponseUtils.RESPONSE_STATUS_400, "Invalid query params"));

		} catch (Exception e) {
			LOGGER.error("Exception failed" + e);
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
					.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_400, ResponseUtils.RESPONSE_STATUS_400, "Processing failed"));
		}

	}
	
	@RequestMapping(value = "/showCountDetails", method = RequestMethod.GET)
	public ResponseEntity<ResponseDTO> retrieveRecord(
			@RequestParam(value = "id") String id , @RequestParam(value = "type") String type) {

		try {
			ResponseDTO responseDTO = null;
				switch (type) {
				case "email" ->	responseDTO = retrieveService.retrieveRecordByEmail(id);
				case "firstName" -> responseDTO = retrieveService.retrieveRecordByFirstName(id);
				default -> { return ResponseEntity.status(HttpStatus.BAD_REQUEST) 
						.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_400, ResponseUtils.RESPONSE_STATUS_400, "Invalid query param !"));}
				}// response entity and body using constructor 
				if(responseDTO.getUser()==null) {
					LOGGER.info("Data not found");
					return ResponseEntity.status(HttpStatus.NOT_FOUND)
							.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_404, ResponseUtils.RESPONSE_STATUS_404, "Requested data not found"));
					}
		}catch (Exception e) {
			LOGGER.error("Exception failed" + e);
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
					.body(new ResponseDTO(ResponseUtils.RESPONSE_CODE_400, ResponseUtils.RESPONSE_STATUS_400, "Processing failed"));
		}
		return null;
	}

}