package com.flight.reservation.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightReservationBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightReservationBatchApplication.class, args);
	}

}
