package com.flight.reservation.app.helper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.flight.reservation.app.entities.User;
import com.flight.reservation.app.repository.RoleRepository;
import com.flight.reservation.app.repository.UserRepository;

@Component
public class RetrieveUsersHelper {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	RoleRepository roleRepository;

	public long getAllUserCount() {
		return userRepository.count();
	}

	public List<User> getUsersDetails() {
		return userRepository.findAll();
	}

	public long getAllRolesCount() {
		return roleRepository.count();
	}
	
	public User getRecordByEmail(String email) {
		return new User();
	}
	
	public User getRecordByFirstName(String firstName) {
		return new User();
	}
}
