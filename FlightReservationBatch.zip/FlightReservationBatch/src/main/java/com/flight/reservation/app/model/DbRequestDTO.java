package com.flight.reservation.app.model;

import java.util.ArrayList;
import java.util.List;

import com.flight.reservation.app.entities.Role;
import com.flight.reservation.app.entities.User;

public class DbRequestDTO {

	List<User> userRec = new ArrayList<>();
	List<Role> roleRec = new ArrayList<>();

	public List<User> getUserRec() {
		return userRec;
	}

	public void setUserRec(List<User> userRec) {
		this.userRec = userRec;
	}

	public List<Role> getRoleRec() {
		return roleRec;
	}

	public void setRoleRec(List<Role> roleRec) {
		this.roleRec = roleRec;
	}

}
