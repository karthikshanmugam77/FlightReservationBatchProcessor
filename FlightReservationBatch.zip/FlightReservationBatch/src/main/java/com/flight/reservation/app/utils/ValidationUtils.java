package com.flight.reservation.app.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ValidationUtils {

	public static String[] allowedTypes;

	@Value("${app.allowed.searchtypes}")
	public void setMinimumLogFlag(String searchTypeTemp) {
		allowedTypes = searchTypeTemp.split(",");
	}

}
